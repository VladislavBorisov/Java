package edu.pragmatic.examples.strings;

/**
 * This is a program that parses a text and determines the number of occurrences
 * of that word within that text
 * 
 */
public class SubstringExtractor {

//	public int countOccurencesOfWord(String word, String text) {
//		
//	}
//
//	public static void main(String[] args) {
//		String text = "We are living in a yellow submarine. We don't" +  
//					  "have anything else. Inside the submarine is"  +
//					  "very tight. So we are drinking all the day. " +
//					  "We will move out of it in 5 days." ;
//		
//		SubstringExtractor extractor = new SubstringExtractor();
//		System.out.println(extractor.countOccurencesOfWord("in", text));
//		
//	}
}
