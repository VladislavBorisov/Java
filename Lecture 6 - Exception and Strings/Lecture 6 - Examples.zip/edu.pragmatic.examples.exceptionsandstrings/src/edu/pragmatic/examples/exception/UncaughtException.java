package edu.pragmatic.examples.exception;

public class UncaughtException {
	
	public static void main(String[] args) {
		int a = 5;
		int b = 0;
		
		System.out.println(a / b);
	}

}
